tar czvf buddy-v100_0_3.tar.gz buddy/
tar czvf fellpflege-v43_1_5.tar.gz
tar czvf futternapf-v2_0_2.tar.gz futternapf/
tar czvf katzenfutter-v44_0_3.tar.gz katzenfutter/
tar czvf scotty-v42_0_2.tar.gz scotty/
tar czvf tapwater-v2_1.tar.gz tapwater/
tar czvf packages.tar.gz * 

